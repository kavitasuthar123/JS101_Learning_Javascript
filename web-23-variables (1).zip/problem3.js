let name = "kavita suthar";
let age = 20;

console.log(name,typeof(name));
console.log(age,typeof(age));
