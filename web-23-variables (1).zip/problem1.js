let name1 ="masai school";
let name2 = "A transformation in education";
console.log(name1)
console.log(name2)