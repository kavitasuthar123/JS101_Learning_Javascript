
let x=12;
console.log(x)