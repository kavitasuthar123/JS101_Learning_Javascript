let name = "kavita suthar";
school = "S.S.M senior secondary school";
section = "B";
rollno = 23;


physics = 45;
chemistry = 41;
biology = 47;

grade = "A";
console.log("name=",name);
 console.log ("section=",section);
console.log  ("rollno=",rollno);
 console.log ("physica=",physics);
console.log  ("chemistry=",chemistry);
 console.log ("biology=",biology);
console.log ("grade=",grade);