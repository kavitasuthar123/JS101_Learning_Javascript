let name ="kavita suthar";
  name="shobha ram";
  name="sumetra devi suthar";
console.log(name);